<!DOCTYPE html>
<html>
<head>
	<title>Forbidden Access</title>
	<link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
</head>
<body>
	<div class="jumbotron">
		<div class="text-center">
			<h2 class="text-danger">Error 403: Forbidden Access</h2>
			<p>Maaf, Anda tidak memiliki hak akses kemari. Silahkan kembali.</p>
			<a href=".."><button class="btn btn-default"><span class="glyphicon glyphicon-home"></span> Home</button></a>
			<br>
			<h5>Del Lab Copyright 2019 by Sistem Informasi IT Del</p>
		</div>
	</div>
</body>
</html>